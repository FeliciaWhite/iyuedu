# 配置列表功能开发文档

## 一、功能概述

配置列表是一个为阅读App朗读引擎打造的**角色/音色配置管理界面**，以分组折叠列表的形式展示所有朗读配置，支持增删改查、拖拽排序、启用/禁用切换，以及带搜索的高级编辑弹窗。

### 核心功能清单

| 功能 | 说明 |
|------|------|
| 分组折叠列表 | 配置按分组展示，点击分组标题展开/收起 |
| 分组拖拽排序 | 长按分组标题上下拖拽调整分组顺序 |
| 配置项拖拽排序 | 长按配置卡片上下拖拽调整同组内顺序 |
| 批量启用/禁用 | 点击分组状态按钮，一键切换全组启用/禁用状态 |
| 单条启用/禁用 | 每条配置独立开关 |
| 新增配置/分组 | 顶部"新增"按钮，支持新增配置或分组 |
| 复制配置 | 弹出菜单中选择"复制配置" |
| 删除配置/分组 | 弹出菜单中删除，带二次确认 |
| 按标签排序 | 分组菜单中按预设标签顺序自动排序 |
| 重命名分组 | 分组菜单中修改分组名称 |
| 带搜索的编辑弹窗 | 标签、预设提示词、发音人均支持搜索过滤 |
| 发音人分类筛选 | 全部/高级/情感/女声/男声/成曲 六类筛选 |
| 高级音色预设 | 高级音色自动显示预设提示词选择框 |
| 情感音色情绪 | 情感音色自动显示情绪多选框 |
| 发音人搜索选择 | 点击发音人Spinner弹出带搜索的picker |
| JSON格式兼容 | voice_list.json 和 rule_presets.json 支持 `{"data":[...]}` 和 `[...]` 两种格式 |
| 保存后重新选中 | 编辑弹窗加载时正确恢复上次保存的发音人选中项 |

---

## 二、文件结构

```
app/src/main/java/io/legado/app/ui/book/read/config/
└── ConfigListDialog.kt          # 核心逻辑（~1158行）

app/src/main/res/layout/
├── dialog_config_list.xml       # 配置列表弹窗主布局
├── dialog_config_edit.xml       # 编辑配置弹窗布局
├── item_config_group.xml        # 分组项RecyclerView item
└── item_config_entry.xml        # 配置项RecyclerView item

app/src/main/res/drawable/
├── ic_expand_less.xml           # 展开图标（分组收起状态）
├── ic_expand_more.xml           # 收起图标（分组展开状态）
├── ic_more_vert.xml             # 更多操作按钮图标
└── bg_spinner.xml               # Spinner背景框

app/src/main/res/values/
└── styles.xml                   # dialog_style 弹窗样式
```

---

## 三、数据模型

### 核心数据结构

```kotlin
// 配置分组
data class ConfigGroup(
    val group: GroupInfo,
    val list: MutableList<ConfigItem>,
    var originalJson: JSONObject? = null  // 保留原始JSON，回写时不丢失未知字段
)

// 分组信息
data class GroupInfo(var id: Long, var name: String)

// 单条配置
data class ConfigItem(
    var id: Long,
    var displayName: String,
    var groupId: Long,
    var enabled: Boolean = true,
    var config: ConfigDetail,
    var originalJson: JSONObject? = null
)

// 配置详情（与阅读App原有JSON结构对齐）
data class ConfigDetail(
    var speechRule: SpeechRule? = null,    // 标签规则
    var audioParams: AudioParams? = null,  // 语速/音量
    var audioFormat: AudioFormat? = null,  // 采样率
    var source: Source? = null             // 音源配置
)

// 朗读规则标签
data class SpeechRule(var tag: String = "", var tagName: String = "")

// 音频参数
data class AudioParams(var speed: Double = 1.0, var volume: Double = 1.0)

// 音频格式
data class AudioFormat(var sampleRate: String = "")

// 音源
data class Source(
    var speed: Double = 1.0,
    var volume: Double = 1.0,
    var voice: String = "",          // 发音人voice_id
    var data: SourceData? = null
)

// 音源附加数据
data class SourceData(var contextTexts: String = "", var emotion: String = "")

// 音色信息（从voice_list.json解析）
data class VoiceInfo(
    val voice_id: String,
    val name: String,
    val gender: String,
    val is_pro: Boolean = false,      // 高级音色
    val is_emotion: Boolean = false,  // 情感音色
    val is_singing: Boolean = false,  // 成曲音色
    val emotions: List<String>? = null
)

// 预设提示词（从rule_presets.json解析）
data class PresetItem(val name: String, val rules: List<String>? = null)
```

### 扁平化列表（RecyclerView展示用）

```kotlin
sealed class FlatItem {
    data class GroupHeader(val groupIndex: Int, val group: ConfigGroup, val isExpanded: Boolean) : FlatItem()
    data class ChildItem(val groupIndex: Int, val childIndex: Int, val item: ConfigItem) : FlatItem()
}
```

分组和配置项混合在一个 `RecyclerView` 中展示。`expandedGroupIndex` 记录当前展开的分组索引，只有展开的分组才会显示其下的配置项。

---

## 四、数据文件

配置列表从以下三个 JSON 文件读取数据，文件路径固定：

```
/storage/emulated/0/Download/chajian/mingwuyan/
├── jiaoseliebiao-list.json    # 配置列表（主数据）
├── voice_list.json            # 音色列表
└── rule_presets.json          # 预设提示词列表
```

### jiaoseliebiao-list.json 格式示例

```json
[
  {
    "group": {
      "id": 1698765432000,
      "name": "主角组",
      "order": 1
    },
    "list": [
      {
        "id": 1698765432100,
        "displayName": "男主",
        "groupId": 1698765432000,
        "isEnabled": true,
        "order": 1,
        "config": {
          "#type": "tts",
          "speechRule": {
            "tag": "男主01",
            "tagName": "主角 男主01"
          },
          "audioParams": {
            "speed": 1.0,
            "volume": 1.0
          },
          "audioFormat": {
            "sampleRate": "24000"
          },
          "source": {
            "#type": "plugin",
            "locale": "all",
            "pluginId": "maoxiang.tts.gj",
            "voice": "zh_male_silang_emo_v2_mars_bigtts",
            "speed": 1.0,
            "volume": 1.0,
            "data": {
              "contextTexts": "",
              "emotion": ""
            }
          }
        }
      }
    ]
  }
]
```

### voice_list.json 格式（兼容两种）

```json
// 方式1：对象包裹
{"data": [{"voice_id": "xxx", "name": "...", ...}]}

// 方式2：直接数组
[{"voice_id": "xxx", "name": "...", ...}]
```

### rule_presets.json 格式（兼容两种）

```json
// 方式1：对象包裹
{"data": [{"name": "温柔", "rules": ["..."]}, ...]}

// 方式2：直接数组
[{"name": "温柔", "rules": ["..."]}, ...]
```

---

## 五、核心实现详解

### 5.1 Dialog 初始化流程

```kotlin
override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
    rootView = requireActivity().layoutInflater.inflate(R.layout.dialog_config_list, null)
    initViews()
    initColors()          // 根据深色/浅色模式设置文字颜色
    loadAllData()         // 加载三个JSON文件
    setupRecyclerView()   // 初始化RecyclerView + 拖拽
    setupListeners()      // 绑定按钮点击
    // ...创建全屏Dialog
}
```

### 5.2 RecyclerView + ItemTouchHelper 拖拽实现

Adapter 采用多 ViewType 设计：
- `type=0` → `GroupHolder`（分组标题）
- `type=1` → `ChildHolder`（配置卡片）

`ItemTouchHelper.SimpleCallback` 处理拖拽逻辑：
- 判断拖拽双方类型，**分组↔分组**、**子项↔子项（同组）** 才允许交换
- 交换后调用 `Collections.swap()` 修改底层 `configData`，然后 `updateData()` 刷新列表并保存

```kotlin
override fun onMove(...): Boolean {
    when {
        // 分组拖拽
        fromItem is GroupHeader && toItem is GroupHeader -> {
            Collections.swap(configData, fromItem.groupIndex, toItem.groupIndex)
            expandedGroupIndex = toItem.groupIndex
            adapter.updateData(buildFlatList())
            saveConfigData()
        }
        // 子项拖拽（同组）
        fromItem is ChildItem && toItem is ChildItem -> {
            val group = configData[fromItem.groupIndex]
            Collections.swap(group.list, fromItem.childIndex, toItem.childIndex)
            adapter.updateData(buildFlatList())
            saveConfigData()
        }
    }
}
```

### 5.3 带搜索的选择器

```kotlin
private fun showSearchablePicker(title, items, selectedPos, onSelect)
```

实现原理：
1. 动态构建一个包含 `EditText`（搜索框）+ `ListView`（结果列表）的 `LinearLayout`
2. `EditText` 添加 `TextWatcher`，过滤时清空 adapter 重新添加匹配项
3. `ListView` 点击后通过 `items.indexOf(text)` 找到原始索引，回调给调用方

被用于：标签选择、预设提示词选择、发音人选择。

### 5.4 编辑弹窗的显隐联动

根据选中的发音人自动显隐对应区域：

```kotlin
fun updateVisibility() {
    val selVoice = getSelectedVoice(spinnerVoice)
    // 高级音色 → 显示预设提示词选择
    llPreset.visibility = if (selVoice?.is_pro == true) View.VISIBLE else View.GONE
    // 情感音色 → 显示情绪多选
    if (selVoice?.is_emotion == true && selVoice.emotions != null) {
        llEmotion.visibility = View.VISIBLE
    } else {
        llEmotion.visibility = View.GONE
    }
}
```

### 5.5 发音人分类筛选

```kotlin
private fun updateVoiceSpinner(spinner, category, selectedVoiceId) {
    val filtered = when (category) {
        "pro"      -> voiceData.filter { it.is_pro }
        "emotion"  -> voiceData.filter { it.is_emotion }
        "female"   -> voiceData.filter { it.gender == "女性" && !it.is_pro && !it.is_emotion && !it.is_singing }
        "male"     -> voiceData.filter { it.gender == "男性" && !it.is_pro && !it.is_emotion && !it.is_singing }
        "sing"     -> voiceData.filter { it.is_singing }
        else       -> voiceData
    }
    spinner.adapter = ArrayAdapter(..., filtered.map { "${it.name}(${it.gender})" })
    spinner.tag = filtered  // 关键：把 VoiceInfo 列表存到 tag，后续可通过 voice_id 反查
    val selIndex = filtered.indexOfFirst { it.voice_id == selectedVoiceId }
    if (selIndex >= 0) spinner.setSelection(selIndex)
}
```

### 5.6 保存后重新选中发音人（关键修复）

问题：编辑弹窗初始化时，`spinnerCategory.setSelection()` 会触发 `onItemSelected`，导致 `updateVoiceSpinner(..., "")` 把已保存的 `voiceId` 重置为空字符串。

修复方案：**先初始化 setSelection 和 updateVoiceSpinner，再设置监听器**。这样初始化阶段根本不存在 listener，彻底杜绝回调干扰。

```kotlin
// 先初始化（此时无监听器）
spinnerCategory.setSelection(catKeys.indexOf(currentCat))
updateVoiceSpinner(spinnerVoice, currentCat, src.voice)
updateVisibility()

// 额外保险：post 延迟二次确认
spinnerVoice.post {
    val savedVoiceId = src.voice
    val voiceList = spinnerVoice.tag as? List<VoiceInfo> ?: return@post
    val idx = voiceList.indexOfFirst { it.voice_id == savedVoiceId }
    if (idx >= 0 && spinnerVoice.selectedItemPosition != idx) {
        spinnerVoice.setSelection(idx)
    }
}

// 再设置监听器
spinnerVoice.onItemSelectedListener = ...
spinnerCategory.onItemSelectedListener = ...
```

### 5.7 原始 JSON 保留策略

为了防止编辑保存时丢失 JSON 中未在 UI 中展示的其他字段，每条配置和每个分组都保留 `originalJson`：

```kotlin
data class ConfigItem(..., var originalJson: JSONObject? = null)
data class ConfigGroup(..., var originalJson: JSONObject? = null)
```

加载时：`item.originalJson = JSONObject(itObj.toString())`

保存时：在 `originalJson` 基础上修改已知字段，未知字段自然保留。

---

## 六、标签体系

标签用于朗读时匹配不同角色/场景，编辑弹窗中通过搜索选择器选择。

```kotlin
// 主角（各10个编号）
男主01 ~ 男主10
女主01 ~ 女主10

// 批量角色（各100个编号）
少女01 ~ 少女100
少年01 ~ 少年100
女青年01 ~ 女青年100
男青年01 ~ 男青年100
女中年01 ~ 女中年100
男中年01 ~ 男中年100
女老年01 ~ 女老年100
男老年01 ~ 男老年100
女童01 ~ 女童100
男童01 ~ 男童100
特殊男01 ~ 特殊男20
特殊女01 ~ 特殊女20

// 特殊标签
【】括号发音人 / 在线音效 / 「」括号发音人 / 『对话旁白』
旁白
```

---

## 七、集成到其他项目

### 7.1 入口调用

在朗读控制面板（如 `ReadAloudDialog`）中添加入口：

```kotlin
llConfigList.setOnClickListener {
    ConfigListDialog().show(childFragmentManager, "configListDialog")
}
```

### 7.2 布局入口

在 `dialog_read_aloud.xml`（朗读控制面板布局）中添加一个 LinearLayout：

```xml
<LinearLayout
    android:id="@+id/ll_config_list"
    android:layout_width="0dp"
    android:layout_height="wrap_content"
    android:layout_weight="1"
    android:background="?android:attr/selectableItemBackgroundBorderless"
    android:clickable="true"
    android:focusable="true"
    android:gravity="center"
    android:orientation="vertical"
    android:padding="4dp">

    <androidx.appcompat.widget.AppCompatImageView
        android:layout_width="24dp"
        android:layout_height="24dp"
        android:src="@drawable/ic_cfg_source" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="2dp"
        android:text="配置列表"
        android:textColor="@color/primaryText"
        android:textSize="11sp" />
</LinearLayout>
```

### 7.3 依赖检查

确保项目中已有以下依赖（阅读App通常已包含）：

```groovy
implementation 'androidx.recyclerview:recyclerview:1.3.x'
implementation 'androidx.cardview:cardview:1.0.x'
```

### 7.4 文件放置

按本压缩包中的目录结构，将文件复制到对应路径即可。如果目标项目路径不同，注意修改 `ConfigListDialog.kt` 顶部的 `package` 声明和 `import` 路径。

---

## 八、注意事项

1. **文件路径**：三个 JSON 文件（`jiaoseliebiao-list.json`、`voice_list.json`、`rule_presets.json`）必须放在 `/storage/emulated/0/Download/chajian/mingwuyan/` 目录下。
2. **权限**：需要存储权限才能读写外部存储的 JSON 文件。
3. **语音列表**：发音人数据从 `voice_list.json` 加载，如果文件为空或格式错误，发音人选择框将为空。
4. **深色模式**：`initColors()` 方法会根据系统主题自动调整文字颜色。
5. **未知字段保留**：通过 `originalJson` 机制，保存时不会丢失 JSON 中未在 UI 中展示的其他字段。
