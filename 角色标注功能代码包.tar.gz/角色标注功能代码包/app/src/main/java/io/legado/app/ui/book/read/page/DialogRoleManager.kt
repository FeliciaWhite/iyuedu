package io.legado.app.ui.book.read.page

import android.text.TextPaint
import io.legado.app.help.config.AppConfig
import io.legado.app.help.config.ReadBookConfig
import io.legado.app.ui.book.read.page.entities.TextChapter
import io.legado.app.ui.book.read.page.provider.ChapterProvider
import io.legado.app.utils.dpToPx
import org.json.JSONObject
import java.io.File

object DialogRoleManager {

    private const val CACHE_ROOT = "/storage/emulated/0/Download/chajian/xiaoshuo/"

    data class RoleInfo(
        val seq: Int,
        var name: String,
        var gender: String,
        var age: String,
        val dialogText: String?
    )

    data class RoleAnnotation(
        val seq: Int,
        val columnIndex: Int,
        val name: String,
        val gender: String,
        val age: String,
        val fullName: String,
        val labelStart: Float,
        val labelEnd: Float
    )

    private val memoryCache = hashMapOf<String, Map<Int, RoleInfo>>()

    private fun sanitizeFileName(name: String): String {
        return name.replace("?", "？")
            .replace(Regex("[\\\\/:*?\"<>|]"), "＿")
    }

    private fun getCacheFile(bookName: String, chapterTitle: String): File {
        val dir = File(CACHE_ROOT + sanitizeFileName(bookName))
        if (!dir.exists()) dir.mkdirs()
        return File(dir, sanitizeFileName(chapterTitle) + ".json")
    }

    fun loadChapterCache(bookName: String, chapterTitle: String): Map<Int, RoleInfo> {
        val cacheKey = "$bookName|$chapterTitle"
        memoryCache[cacheKey]?.let { return it }

        val file = getCacheFile(bookName, chapterTitle)
        if (!file.exists()) return emptyMap()

        return try {
            val json = JSONObject(file.readText())
            val results = json.optJSONObject("results") ?: return emptyMap()
            val map = mutableMapOf<Int, RoleInfo>()
            results.keys().forEach { key ->
                val seq = key.toIntOrNull() ?: return@forEach
                val obj = results.getJSONObject(key)
                map[seq] = RoleInfo(
                    seq = seq,
                    name = obj.optString("name", ""),
                    gender = obj.optString("gender", ""),
                    age = obj.optString("age", ""),
                    dialogText = obj.optString("dialogText", null)
                )
            }
            memoryCache[cacheKey] = map
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun saveRole(
        bookName: String,
        chapterTitle: String,
        seq: Int,
        name: String,
        gender: String,
        age: String
    ) {
        val file = getCacheFile(bookName, chapterTitle)
        val json = if (file.exists()) {
            try {
                JSONObject(file.readText())
            } catch (e: Exception) {
                JSONObject()
            }
        } else {
            JSONObject()
        }

        val results = json.optJSONObject("results")
            ?: JSONObject().also { json.put("results", it) }
        val existing = results.optJSONObject(seq.toString()) ?: JSONObject()
        existing.put("name", name)
        existing.put("gender", gender)
        existing.put("age", age)
        if (!existing.has("dialogText")) existing.put("dialogText", "")
        results.put(seq.toString(), existing)

        if (!json.has("title")) json.put("title", chapterTitle)

        file.writeText(json.toString(2))

        val cacheKey = "$bookName|$chapterTitle"
        val map = memoryCache[cacheKey]?.toMutableMap() ?: mutableMapOf()
        val old = map[seq]
        map[seq] = RoleInfo(seq, name, gender, age, old?.dialogText)
        memoryCache[cacheKey] = map
    }

    fun clearChapterCache(bookName: String, chapterTitle: String) {
        memoryCache.remove("$bookName|$chapterTitle")
    }

    fun collectNeighborRoles(
        bookName: String,
        chapterTitle: String,
        currentSeq: Int,
        currentName: String,
        chapterTitles: List<String>,
        currentChapterIndex: Int
    ): List<RoleInfo> {
        val seen = mutableSetOf<String>()
        if (currentName.isNotBlank()) seen.add(currentName)

        val prevRoles = mutableListOf<RoleInfo>()
        val nextRoles = mutableListOf<RoleInfo>()

        val currentCache = loadChapterCache(bookName, chapterTitle)

        // 当前章节：前面4个（seq 递减，越近越前）
        var i = currentSeq - 1
        while (i >= 1 && prevRoles.size < 4) {
            currentCache[i]?.let { role ->
                if (role.name.isNotBlank() && !seen.contains(role.name)) {
                    seen.add(role.name)
                    prevRoles.add(role)
                }
            }
            i--
        }

        // 当前章节：后面5个（seq 递增）
        i = currentSeq + 1
        val maxSeq = currentCache.keys.maxOrNull() ?: Int.MAX_VALUE
        while (i <= maxSeq && nextRoles.size < 5) {
            currentCache[i]?.let { role ->
                if (role.name.isNotBlank() && !seen.contains(role.name)) {
                    seen.add(role.name)
                    nextRoles.add(role)
                }
            }
            i++
        }

        // 向前跨章节补充（从上一章末尾往前取）
        var chapterIdx = currentChapterIndex - 1
        while (chapterIdx >= 0 && prevRoles.size < 4) {
            val prevCache = loadChapterCache(bookName, chapterTitles[chapterIdx])
            if (prevCache.isNotEmpty()) {
                val prevMaxSeq = prevCache.keys.maxOrNull() ?: 0
                var seq = prevMaxSeq
                while (seq >= 1 && prevRoles.size < 4) {
                    prevCache[seq]?.let { role ->
                        if (role.name.isNotBlank() && !seen.contains(role.name)) {
                            seen.add(role.name)
                            prevRoles.add(role)
                        }
                    }
                    seq--
                }
            }
            chapterIdx--
        }

        // 向后跨章节补充（从下一章开头往后取）
        chapterIdx = currentChapterIndex + 1
        while (chapterIdx < chapterTitles.size && nextRoles.size < 5) {
            val nextCache = loadChapterCache(bookName, chapterTitles[chapterIdx])
            if (nextCache.isNotEmpty()) {
                val nextMaxSeq = nextCache.keys.maxOrNull() ?: 0
                var seq = 1
                while (seq <= nextMaxSeq && nextRoles.size < 5) {
                    nextCache[seq]?.let { role ->
                        if (role.name.isNotBlank() && !seen.contains(role.name)) {
                            seen.add(role.name)
                            nextRoles.add(role)
                        }
                    }
                    seq++
                }
            }
            chapterIdx++
        }

        return prevRoles.reversed() + nextRoles
    }

    fun attachAnnotations(textChapter: TextChapter, bookName: String) {
        if (!AppConfig.showRoleAnnotation) return
        if (bookName.isBlank()) return
        val cache = loadChapterCache(bookName, textChapter.title)
        if (cache.isEmpty()) return

        var globalSeq = 0
        textChapter.pages.forEach { page ->
            page.lines.forEach { line ->
                val tempAnnotations = mutableListOf<RoleAnnotation>()
                line.columns.forEachIndexed { index, column ->
                    if (column is io.legado.app.ui.book.read.page.entities.column.TextColumn
                        && column.charData == "“"
                    ) {
                        globalSeq++
                        val role = cache[globalSeq] ?: return@forEachIndexed
                        if (role.name.isBlank()) return@forEachIndexed

                        val label = role.name.take(5)
                        val paint = annotationPaint
                        paint.textSize = ChapterProvider.contentPaint.textSize * 0.55f
                        val labelWidth = paint.measureText(label)
                        val x = column.start

                        tempAnnotations.add(
                            RoleAnnotation(
                                seq = globalSeq,
                                columnIndex = index,
                                name = label,
                                gender = role.gender,
                                age = role.age,
                                fullName = role.name,
                                labelStart = x,
                                labelEnd = x + labelWidth
                            )
                        )
                    }
                }
                line.setRoleAnnotations(tempAnnotations)
            }
        }
    }

    val annotationPaint: TextPaint by lazy {
        TextPaint(ChapterProvider.contentPaint).apply {
            isAntiAlias = true
        }
    }
}
